﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChronoStick_Input.Model
{
    public enum TypeMessageConfig
    {
        Inconnu = 0,
        NombrePatineur = 1,
        DelaisPing = 2,
        DelaisTourPatineur = 3,
        DelaisDepart = 4,
        Terminer = 5
    }
}
