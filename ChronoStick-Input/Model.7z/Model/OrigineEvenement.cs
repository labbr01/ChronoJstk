﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChronoStick_Input.Model
{
    public enum OrigineEvenement
    {
        Inconnu = 0,
        USB = 1,
        Souris = 2,
        Systeme = 3
    }
}
