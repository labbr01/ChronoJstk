﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChronoStick_Input.Model
{
    public class BoutonEventArgs : EventArgs
    {
        public BoutonEventArgs(int noBouton, bool enfonce)
        {
            this.NoBouton = noBouton;
            this.Enfonce = enfonce;
            this.Heure = DateTime.Now;
        }

        public int NoBouton { get; set; }
        public bool Enfonce { get; set; }
        public DateTime Heure { get; set; }
    }
}
