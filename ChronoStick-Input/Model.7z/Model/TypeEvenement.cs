﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChronoStick_Input.Model
{
    public enum TypeEvenement
    {
        Indefini = 0,
        Depart = 1,
        Tour = 2,        
        Ping = 3,
        Demarrage = 4,
        Terminer = 5
    }
}
